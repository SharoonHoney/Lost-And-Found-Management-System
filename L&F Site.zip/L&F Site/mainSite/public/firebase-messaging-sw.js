importScripts('https://www.gstatic.com/firebasejs/8.7.1/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.7.1/firebase-messaging.js');
// importScripts('serviceWorker.min.js');
// // importScripts('push.min.js');
// importScripts('https://github.com/Nickersoft/push.js/blob/master/bin/push.min.js');
// importScripts('https://github.com/Nickersoft/push.js/blob/master/bin/serviceWorker.min.js');

const firebaseConfig = {
  apiKey: "AIzaSyD53m9EJCSDXXwxMG3C9kOB-qF2-W3561w",
  authDomain: "lostandfoundmanagementsystem.firebaseapp.com",
  projectId: "lostandfoundmanagementsystem",
  storageBucket: "lostandfoundmanagementsystem.appspot.com",
  messagingSenderId: "53875721393",
  appId: "1:53875721393:web:6f945a8701d2c110a00e90",
  measurementId: "G-CPR08W8Z5N"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log('[firebase-messaging-sw.js] Received background message ', payload);
  // Customize notification here
  const notificationTitle = 'You recieved a new message';
  const notificationOptions = {
    // body: 'You have.',
    body: payload.data.message,
    // body: Push.create("New Notification", {
    //                         body: payload.data.message,
    //                         // icon: '/icon.png',
    //                         timeout: 4000,
    //                         onClick: function () {
    //                             window.focus();
    //                             this.close();
    //                         }
    //                     })
    //                 ,
    
    // click_action: payload.data.url,
    icon: 'images/navLAF_logo2.png',
    data : {
      time: new Date(Date.now()).toString(),
      openURL: payload.data.openURL
    }
    
    // action: { url:payload.data.openURL }, //the url which we gonna use later
      // action: [{url: "https://lostandfound.ga", title: "View"}]
  };

  return self.registration.showNotification(notificationTitle, notificationOptions);
  
});

self.addEventListener('notificationclick', function(event) {
  console.log(event.notification);
  var action_click = event.notification.data.openURL;
  event.notification.close();
  
  event.waitUntil(
    clients.openWindow(action_click)
  );
});
