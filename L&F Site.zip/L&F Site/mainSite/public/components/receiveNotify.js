const FIREBASE_MESSAGING = firebase.messaging();
const FIRESTORE_DB = firebase.firestore();
const FIRBASE_AUTH = firebase.auth();

FIREBASE_MESSAGING.onTokenRefresh(handleTokenRefresh);

let UserID = "";

FIRBASE_AUTH.onAuthStateChanged((user)=>{
    if(user){
        UserID = user.uid;
        subscribe(UserID);
    }
    else {
        userContainer.innerText = "No User";
    }
        
});

function subscribe(ID) {
    // alert("Subscribe Successfully!");
    FIREBASE_MESSAGING.requestPermission()
        .then(()=> handleTokenRefresh(ID))
        .catch(()=> console.log("user didn't give permission"));

}

// function unSubscribe() {
//     // alert("Subscribe Successfully!");
//     FIREBASE_MESSAGING.requestPermission()
//         .then(()=> deleteToken())
//         .catch(()=> console.log("user didn't give permission"));
// }

function handleTokenRefresh(ID) {
   return FIREBASE_MESSAGING.getToken()
        .then((token) => {
             console.log(token)
             FIRESTORE_DB.collection("Claim_Notification").doc(ID).set({
                user: FIRBASE_AUTH.currentUser.email,
                token: token
             })
             .then(()=>{
                 console.log("Add to DB successfully!");
                 
             })
             .catch((error)=>{
                 console.log("Error code: "+error.code+", Error message: "+error.message);
             })
            }); 
}


