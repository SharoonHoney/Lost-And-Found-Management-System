let home = document.getElementById("home");

let laptop = document.getElementById("laptop");
let phone = document.getElementById("phone");
let bag = document.getElementById("bag");
let wallet = document.getElementById("wallet");

let lostItem = document.getElementById("lostItem");
let foundItem = document.getElementById("foundItem");
let about = document.getElementById("about");
let contact = document.getElementById("contact");

// ------- Pages -----------

let homePage = document.getElementById("homePage");

let laptopPage = document.getElementById("laptopPage");
let phonePage = document.getElementById("phonePage");
let bagPage = document.getElementById("bagPage");
let walletPage = document.getElementById("walletPage");

let lostItemPage = document.getElementById("lostItemPage");
let foundItemPage = document.getElementById("foundItemPage");
let aboutUsPage = document.getElementById("aboutUs");
let contactUsPage = document.getElementById("contactUs");

// contact.onclick = () => {
//     contactUsPage.style.display = "block";
//     contact.classList.add("active");
//     // contactUsPage.innerHTML = "<h2>Hello</h2>";
//     homePage.style.display = "none";
//     home.classList.remove("active");

    
//     // HomePage("Lost");
//     // HomePage("Found");
//     // HomePage("Fou");

// }

let totalLostItem = 100;

function HomePage(x){
    homePage.innerHTML = "<div class='card'><div class='card-header'><h4> Total Registered, "+x+" Item: "+totalLostItem+" </h4></div> <div class='card-body'><blockquote class='blockquote mb-0'><p>A well-known quote, contained in a blockquote element.</p><footer class='blockquote-footer'>Someone famous in <cite title='Source Title'>Source Title</cite></footer></blockquote></div> </div>";
}

