//----------------Configuration-------------------

const firebaseConfig = {
    apiKey: "AIzaSyD53m9EJCSDXXwxMG3C9kOB-qF2-W3561w",
    authDomain: "lostandfoundmanagementsystem.firebaseapp.com",
    projectId: "lostandfoundmanagementsystem",
    storageBucket: "lostandfoundmanagementsystem.appspot.com",
    messagingSenderId: "53875721393",
    appId: "1:53875721393:web:6f945a8701d2c110a00e90",
    measurementId: "G-CPR08W8Z5N"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();