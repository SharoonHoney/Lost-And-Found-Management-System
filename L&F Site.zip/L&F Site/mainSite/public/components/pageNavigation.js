let MAIN_URL = "pages/";
let page_URL = "homePage.html";


// --------Pages Links ------------------------------
let home = document.getElementById("home");
let lostItem = document.getElementById("lostItem");
let foundItem = document.getElementById("foundItem");
let about = document.getElementById("about");
let contact = document.getElementById("contact");



// By Default HomePage is open
const xhttp = new XMLHttpRequest();
xhttp.onload = function () {
    let key = localStorage.getItem("Page_URL");
    switch (key) {
        case "homePage.html":
            home.classList.add("active");
            lostItem.classList.remove("active");
            foundItem.classList.remove("active");
            about.classList.remove("active");
            contact.classList.remove("active");
            break;
        case "itemslostPage.html":
            home.classList.remove("active");
            lostItem.classList.add("active");
            foundItem.classList.remove("active");
            about.classList.remove("active");
            contact.classList.remove("active");

            break;
        case "itemsfoundPage.html":
            home.classList.remove("active");
            lostItem.classList.remove("active");
            foundItem.classList.add("active");
            about.classList.remove("active");
            contact.classList.remove("active");

            break;
        case "aboutUsPage.html":
            home.classList.remove("active");
            lostItem.classList.remove("active");
            foundItem.classList.remove("active");
            about.classList.add("active");
            contact.classList.remove("active");

            break;
        case "contactUS.html":
            home.classList.remove("active");
            lostItem.classList.remove("active");
            foundItem.classList.remove("active");
            about.classList.remove("active");
            contact.classList.add("active");

            break;

    }
    document.getElementById("container").innerHTML = this.responseText;
}
if (localStorage.getItem("Page_URL") == null) {
    localStorage.setItem("Page_URL", "homePage.html");
}
xhttp.open("GET", MAIN_URL + localStorage.getItem("Page_URL"));
xhttp.send();



// Calling HomePage 
home.onclick = () => {
    page_URL = "homePage.html";
    localStorage.setItem("Page_URL", page_URL);
    
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function () {
        document.getElementById("container").innerHTML = this.responseText;
        home.classList.add("active");
        lostItem.classList.remove("active");
        foundItem.classList.remove("active");
        about.classList.remove("active");
        contact.classList.remove("active");
    }
    xhttp.open("GET", MAIN_URL + "homePage.html");
    xhttp.send();

}


// Calling Lost Item Page 
lostItem.onclick = () => {
    page_URL = "itemslostPage.html";
    localStorage.setItem("Page_URL", page_URL);
    
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function () {
        document.getElementById("container").innerHTML = this.responseText;
        home.classList.remove("active");
        lostItem.classList.add("active");
        foundItem.classList.remove("active");
        about.classList.remove("active");
        contact.classList.remove("active");
    }
    xhttp.open("GET", MAIN_URL + "itemslostPage.html");
    xhttp.send();
}
// Calling Found Item Page 
foundItem.onclick = () => {
    page_URL = "itemsfoundPage.html";
    localStorage.setItem("Page_URL", page_URL);
    
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function () {
        document.getElementById("container").innerHTML = this.responseText;
        home.classList.remove("active");
        lostItem.classList.remove("active");
        foundItem.classList.add("active");
        about.classList.remove("active");
        contact.classList.remove("active");
    }
    xhttp.open("GET", MAIN_URL + "itemsfoundPage.html");
    xhttp.send();


}

// Calling About Page 
about.onclick = () => {
    page_URL = "aboutUsPage.html";
    localStorage.setItem("Page_URL", page_URL);
    
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function () {
        document.getElementById("container").innerHTML = this.responseText;
        home.classList.remove("active");
        lostItem.classList.remove("active");
        foundItem.classList.remove("active");
        about.classList.add("active");
        contact.classList.remove("active");


    }
    xhttp.open("GET", MAIN_URL + "aboutUsPage.html");
    xhttp.send();
}


// Calling ContactUs Page
contact.onclick = () => {
    page_URL = "contactUS.html";
    localStorage.setItem("Page_URL", page_URL);
    
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function () {
        document.getElementById("container").innerHTML = this.responseText;
        home.classList.remove("active");
        lostItem.classList.remove("active");
        foundItem.classList.remove("active");
        about.classList.remove("active");
        contact.classList.add("active");
    }
    xhttp.open("GET", MAIN_URL + "contactUS.html");
    xhttp.send();
}

function gotoLostPage() {
    page_URL = "itemslostPage.html";
    localStorage.setItem("Page_URL", page_URL);
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function () {
        document.getElementById("container").innerHTML = this.responseText;
        home.classList.remove("active");
        lostItem.classList.add("active");
        foundItem.classList.remove("active");
        about.classList.remove("active");
        contact.classList.remove("active");
    }
    xhttp.open("GET", MAIN_URL + "itemslostPage.html");
    xhttp.send();
}

function gotoFoundPage() {
    page_URL = "itemsfoundPage.html";
    localStorage.setItem("Page_URL", page_URL);
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function () {
        document.getElementById("container").innerHTML = this.responseText;
        home.classList.remove("active");
        lostItem.classList.remove("active");
        foundItem.classList.add("active");
        about.classList.remove("active");
        contact.classList.remove("active");
    }
    xhttp.open("GET", MAIN_URL + "itemsfoundPage.html");
    xhttp.send();
}