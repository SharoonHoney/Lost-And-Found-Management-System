let notification = document.getElementById("notification-container");
let marker = document.getElementById("marker");

let claimCloseIcon = document.getElementById("claim-closeIcon");
let claimLaptopImg = document.getElementById("claim-item-img");
let claimLaptopCompany = document.getElementById("claim-laptopCompany");
let claimLaptopModel = document.getElementById("claim-laptopModel");
let claimLaptopOS = document.getElementById("claim-laptopOS");

let AdditionalItemDescription = "";

let FOUND_ID = "";
let CLAIMED_USER = "";

function additionalDescription(value) {
    AdditionalItemDescription = value;
}

// Notification data Container
let notification_list = document.getElementById("notification-list");
// --------End here-----------
claimCloseIcon.onclick = () => {
    document.getElementById("claimContainer").style.display = "none";
}

function notificationClick() {
    notification.style.display = "block";
    document.getElementById("rest-area").style.display = "block";
}

document.getElementById("rest-area").onclick = () => {
    notification.style.display = "none";
    document.getElementById("rest-area").style.display = "none";
}

// ---Check User---
let user_log = "";
firebaseLogin.onAuthStateChanged((user) => {
    if (user) {
        user_log = user.email;
        GetNotification(user_log)
        // claimItem(user_log);
        assignUser(user_log)
        // getClaimData(user_log)
    }
});

function assignUser(user) {
    return user;
}


// -------Read Document-----------------------
function GetNotification() {

    // alert(user_log);
    // alert(user_log.email);
    // cloudDB.collection("Lost_Laptop_Registered").get().then(
    // cloudDB.collection("Notifications").where("user", "==", user_log).
    cloudDB.collection("Notifications").
        onSnapshot(snapshot => {

            let changes = snapshot.docChanges();

            changes.forEach(change => {

                // document.getElementById("info-table").style.visibility = "visible";
                if (change.type == 'added') {

                    if (user_log == change.doc.data().user) {
                        marker.style.visibility = "visible";
                        // showNotification(change.doc.data().uid, change.doc.data().data, change.doc.data().mark);
                        showNotification(change.doc.id, change.doc.data().user, change.doc.data().claim_To_User, change.doc.data().data);
                        document.getElementById("noNotification").style.display = "none";
                        //     Push.create("New Notification", {
                        //         body: "New Notification",
                        //         // icon: '/icon.png',
                        //         timeout: 4000,
                        //         onClick: function () {
                        //             window.focus();
                        //             this.close();
                        //         }
                        //     });
                    }
                    else {
                        // document.getElementById("noNotification").style.display = "block";
                    }
                }


            });
            changes.forEach(change => {

                // document.getElementById("info-table").style.visibility = "visible";
                if (change.doc.data().Mark == "read") {
                    marker.style.visibility = "hidden";
                }


            });

            // marker.innerHTML = counter;
            // alert(counter);    


        });

}



// function showNotification(id, user, data) {
function showNotification(id, user, founduser, data) {
    // notification_list.innerHTML += "<li id='notification-line' onclick=readN(\""+this.id+"\")>Notification: "+mail+"<button type='button' onclick=readNotification(\""+id+"\")>"+mail+"</button></li>";
    // if (user == user_log) {
    // }
    // notification_list.innerHTML += "<li> " + data + " <button type='button' id='notification-btn' onclick=readNotification(\"" + id + "\")> View Details </button><hr></li>";
    notification_list.innerHTML += "<li> " + data + " <button type='button' id='notification-btn' onclick='getClaimData(\"" + user + "\", \"" + founduser + "\")'> View Details </button><hr></li>";


}


let foundUSER = "";
let foundID = "";

function getClaimData(user, founduser) {

    document.getElementById("claimContainer").style.display = "block";

    // cloudDB.collection("Notifications").get().then((querySnapshot) => {
    //     querySnapshot.forEach((doc1) => {

            cloudDB.collection("Found_Laptop_Registered").get().then((querySnapshot) => {
                querySnapshot.forEach((doc) => {
                        // alert("Notification User: "+doc1.data().claim_To_User+", Found user: "+doc2.data().User);
                    if (doc.data().User == founduser) {
                        foundUSER = founduser;
                        foundID = doc.id;
                        // alert("User: "+founduser);

                        claimLaptopImg.src = doc.data().LaptopImg;
                        claimLaptopCompany.innerText = doc.data().LaptopCompany;
                        claimLaptopModel.innerText = doc.data().LaptopModel;
                        claimLaptopOS.innerText = doc.data().LaptopOS;

                        
                        // CLAIMED_USER = doc.data().claim_To_User;
                        
                    }

                });
            });

        // });
    // });
}



let claimBtn = document.getElementById("claim-btn");

let backToClaimBtn = document.getElementById("backToClaimPage");



backToClaimBtn.onclick = () => {
    document.getElementById("claim-btn").style.visibility = "visible";

    document.getElementById("claim-info").style.visibility = "visible";

    document.getElementById("claimArea").style.visibility = "hidden";
    // alert(AdditionalItemDescription);
}

claimBtn.onclick = () => {
    // alert(foundID+", "+foundUSER+", "+user_log);
    // alert(""+foundUSER+""+user_log);
    // alert("Claim Btn: " +FOUND_ID+", Claim User: "+user_log);
    // claimItem(FOUND_ID, user_log);
    // claimItem();

    document.getElementById("claim-btn").style.visibility = "hidden";

    document.getElementById("claim-info").style.visibility = "hidden";

    document.getElementById("claimArea").style.visibility = "visible";
}

let claimSubmitBtn = document.getElementById("claim_submit");


claimSubmitBtn.onclick = () => {
    claimItem(foundID, user_log, foundUSER);
    // FOUND_ID =  
    // alert(FOUND_ID+" "+CLAIMED_USER);
    // alert("Claim Submit");

}    





// function claimItem(ID, CLAIMED_USER) {
function claimItem(FOUND_ID, LOST_USER, FOUND_USER) {
    // claimLaptopImg.style.display = "hidden";
    document.getElementById("claim-btn").style.visibility = "hidden";

    document.getElementById("claim-info").style.visibility = "hidden";

    document.getElementById("claimArea").style.visibility = "visible";

    cloudDB.collection("Found_Laptop_Registered").doc(FOUND_ID).get().then(
        function (doc) {
            if (doc.exists) {
                cloudDB.collection("Claim_Laptop_Registered").add(
                    {
                        Claimed_User: LOST_USER,
                        Found_User: doc.data().User,
                        FoundAddress: doc.data().FoundAddress,
                        LaptopCompany: doc.data().LaptopCompany,
                        LaptopModel: doc.data().LaptopModel,
                        LaptopOS: doc.data().LaptopOS,
                        osVersion: doc.data().osVersion,
                        CPU_Spec: doc.data().CPU_Spec,
                        Ram_Size: doc.data().Ram_Size,
                        Storage_Type: doc.data().Storage_Type,
                        Storage_Size: doc.data().Storage_Size,
                        PasswordProtected: doc.data().PasswordProtected,
                        LaptopImg: doc.data().LaptopImg,
                        Description: doc.data().Description,
                        Additional_Description: AdditionalItemDescription
                    }
                ).then(() => {
                    alert("Claimed Successfully!");
                })
                    .catch((error) => {
                        alert("Error: " + error.message);
                    });

            }
        }
    ).catch(function (error) {
        alert("Error: " + error.message);
    });

    // cloudDB.collection("Claim_Laptop_Registered").get().then((querySnapshot) => {
    //     querySnapshot.forEach((doc) => {

    //         if (doc.data().User == user) {
    //             claimLaptopImg.src = doc.data().LaptopImg;
    //             claimLaptopCompany.innerText = doc.data().LaptopCompany;
    //             claimLaptopModel.innerText = doc.data().LaptopModel;
    //             claimLaptopOS.innerText = doc.data().LaptopOS;
    //             if (doc.data().User != user) {
    //                 alert("No data found!");
    //             }
    //         }

    //     });
    // });


}


// function readN(id) {
//     id.style.color = "black";
// }
function readNotification(id) {
    alert(id);
    // document.getElementById("notification-line").style.color += "black";
    cloudDB.collection("Notifications").doc(id).update({
        mark: "read"
    }).then(
        function () {
            console.log("Notification Successfully!");


        }).catch(
            function (error) {
                alert("Error: " + error.code + ", " + error.message);
            }
        );
}


// GetNotification();