// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();

let firebaseLogin = firebase.auth();

let userContainer = document.getElementById("user-name");
//  // ---Check User---
firebaseLogin.onAuthStateChanged((user) => {
    if (!user) {
        location.replace("newLoginRegister.html");
    }
    else {
      userContainer.innerHTML = user.email;
    }
// else if(switchScreen == 2) {
//     location.replace("newLoginRegister.html");

//    }   
   });

function logOut() {
    firebaseLogin.signOut();
}