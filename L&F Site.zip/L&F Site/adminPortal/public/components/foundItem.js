// Initialize Firebase
// firebase.initializeApp(firebaseConfig);
// firebase.analytics();

let cloudDB = firebase.firestore();
let storage = firebase.storage();
let auth = firebase.auth();

let tbody = document.getElementById("tbLaptop");


let contentContainer = document.getElementById("content-container");

// -------Read Document-----------------------
function RetrieveData() {
    // cloudDB.collection("Lost_Laptop_Registered").get().then(
    cloudDB.collection("Found_Laptop_Registered").
        onSnapshot(snapshot => {

            let changes = snapshot.docChanges();

            // document.getElementById("noData").style.visibility = "visible";
            changes.forEach(change => {
                document.getElementById("loadingLaptop").style.display = "none";
                // document.getElementById("noData").style.visibility = "hidden";

                // document.getElementById("info-table").style.visibility = "visible";
                document.getElementById("info-table").style.visibility = "visible";
                if (change.type == 'added') {
                    AddItemsToLaptopTable(change.doc.id, change.doc.data().User, change.doc.data().FoundAddress, change.doc.data().LaptopCompany, change.doc.data().LaptopModel, change.doc.data().LaptopOS, change.doc.data().osVersion, change.doc.data().PasswordProtected, change.doc.data().LaptopImg, change.doc.data().Description);
                }


            });


        });

    // Retrieve Mobile Phone Data 
    cloudDB.collection("Found_MobilePhone_Registered").
        onSnapshot(snapshot => {

            let changes = snapshot.docChanges();

            // document.getElementById("noData").style.visibility = "visible";
            changes.forEach(change => {
                document.getElementById("loadingMp").style.display = "none";
                // document.getElementById("noData").style.visibility = "hidden";

                // document.getElementById("mp-table").style.visibility = "visible";
                document.getElementById("mp-table").style.visibility = "visible";

                if (change.type == 'added') {
                    AddItemsToPhoneTable(change.doc.id, change.doc.data().User, change.doc.data().LostAddress, change.doc.data().PhoneType, change.doc.data().PhoneCompany, change.doc.data().PhoneModel, change.doc.data().PhoneOS, change.doc.data().osVersion, change.doc.data().AnyPassword, change.doc.data().PhoneImg, change.doc.data().Description);
                }


            });


        });

}

RetrieveData();

let SR = 0;
let SR2 = 0;
function AddItemsToLaptopTable(id, _registerer, _LostAddress, _LaptopCompany, _LaptopModel, _LaptopOS, _osVersion, _AnyPassword, _LaptopImg, _Description) {

    // tbody.innerHTML += "<tr><td>" + (++SR) + "</td><td>" + _registerer + "</td><td>" + _LostAddress + "</td><td><button type='button' class='buttons' id='detailsBtn'  onclick='showDetails(\"" + _registerer + "\",\"" + _LostAddress + "\",\"" + _LaptopCompany + "\",\"" + _LaptopModel + "\",\"" + _LaptopOS + "\",\"" + _osVersion + "\",\"" + _AnyPassword + "\",\"" + _LaptopImg + "\",\"" + _Description + "\")'>details</button></td><td><button type='button' class='buttons' id='approveBtn' onclick='approved(\""+_registerer+"\")'>approve</button></td><td><button type='button' class='buttons' id='deleteBtn' onclick='Delete(\"" + id + "\")'>delete</button></td></tr>";
    tbody.innerHTML += "<tr><td>" + (++SR) + "</td><td>" + _registerer + "</td><td>" + _LostAddress + "</td><td><button type='button' class='buttons' id='detailsBtn'  onclick='showDetails(\"" + _registerer + "\",\"" + _LostAddress + "\",\"" + _LaptopCompany + "\",\"" + _LaptopModel + "\",\"" + _LaptopOS + "\",\"" + _osVersion + "\",\"" + _AnyPassword + "\",\"" + _LaptopImg + "\",\"" + _Description + "\")'>details</button></td><td><button type='button' class='buttons' id='deleteBtn' onclick='Delete(\"" + id + "\")'>delete</button></td></tr>";
}
function AddItemsToPhoneTable(id, _registerer, _LostAddress, _PhoneType, _PhoneCompany, _PhoneModel, _PhoneOS, _osVersion, _AnyPassword, _PhoneImg, _Description) {
    let tbody2 = document.getElementById("tbPhone");
    // tbody2.innerHTML += "<tr><td>" + (++SR2) + "</td><td>" + _registerer + "</td><td>" + _LostAddress + "</td><td><button type='button' class='buttons' id='mp-detailsBtn'  onclick='mpShowDetails(\"" + _registerer + "\",\"" + _LostAddress + "\",\"" + _PhoneType + "\",\"" + _PhoneCompany + "\",\"" + _PhoneModel + "\",\"" + _PhoneOS + "\",\"" + _osVersion + "\",\"" + _AnyPassword + "\",\"" + _PhoneImg + "\",\"" + _Description + "\")'>details</button></td><td><button type='button' class='buttons' id='approveBtn' onclick='approved(\""+_registerer+"\")'>approve</button></td><td><button type='button' class='buttons' id='mp-deleteBtn' onclick='mpDelete(\"" + id + "\")'>delete</button></td></tr>";
    tbody2.innerHTML += "<tr><td>" + (++SR2) + "</td><td>" + _registerer + "</td><td>" + _LostAddress + "</td><td><button type='button' class='buttons' id='mp-detailsBtn'  onclick='mpShowDetails(\"" + _registerer + "\",\"" + _LostAddress + "\",\"" + _PhoneType + "\",\"" + _PhoneCompany + "\",\"" + _PhoneModel + "\",\"" + _PhoneOS + "\",\"" + _osVersion + "\",\"" + _AnyPassword + "\",\"" + _PhoneImg + "\",\"" + _Description + "\")'>details</button></td><td><button type='button' class='buttons' id='mp-deleteBtn' onclick='mpDelete(\"" + id + "\")'>delete</button></td></tr>";
}

// For Notification
function approved(userEmail) {

    cloudDB.collection("Claim_Notification").add({
        User: userEmail,
        Data: "We found your Item",
        Mark: "unread"
    }).then(
        function () {
            // Push.create("New Notification", {
            //     body: userEmail,
            //     // icon: '/icon.png',
            //     timeout: 4000,
            //     onClick: function () {
            //         window.focus();
            //         this.close();
            //     }
            // });
           
            console.log("Notification Successfully!");
        }).catch (
            function (error) {
             alert ("Error: "+error.code+", "+error.message);
            }
        );
}

//------------Show Laptop Details-------------- 
let detailsContent = document.getElementById("details-content");
let closeIcon = "";
let forLostAddress = "";
let forLaptopCompany = "";
let forLaptopModel = "";
let forLaptopOS = "";
let forOSversion = "";
let forAnyPassword = "";
let forLaptopImg = "";
let forDescription = "";

closeIcon = document.getElementById("closeIcon");
forLostAddress = document.getElementById("LostAddress");
forLaptopCompany = document.getElementById("LaptopCompany");
forLaptopModel = document.getElementById("LaptopModel");
forLaptopOS = document.getElementById("LaptopOS");
forOSversion = document.getElementById("osVersion");
forAnyPassword = document.getElementById("AnyPassword");
forLaptopImg = document.getElementById("LaptopImg");
forDescription = document.getElementById("Description");

function showDetails(_registerer, _LostAddress, _LaptopCompany, _LaptopModel, _LaptopOS, _osVersion, _AnyPassword, _LaptopImg, _Description) {
    forLaptopImg.src = _LaptopImg;
    forLostAddress.innerHTML = _LostAddress;
    forLaptopCompany.innerHTML = _LaptopCompany;
    forLaptopModel.innerHTML = _LaptopModel;
    forLaptopOS.innerHTML = _LaptopOS;
    forOSversion.innerHTML = _osVersion;
    forAnyPassword.innerHTML = _AnyPassword;
    forDescription.innerHTML = _Description;

    detailsContent.style.display = "block";
    //  console.log(name);
    //  alert("clicked! "+name);  
}

closeIcon.onclick = () => { detailsContent.style.display = "none"; }

//--------------Show Mobile Phone Details-------------------
let mpdetailsContent = document.getElementById("mp-details-content");
let mpcloseIcon = "";
let formpLostAddress = "";
let formpType = "";
let formpCompany = "";
let formpModel = "";
let formpOS = "";
let formpOSversion = "";
let formpAnyPassword = "";
let formpImg = "";
let formpDescription = "";

mpcloseIcon = document.getElementById("mp-closeIcon");
formpLostAddress = document.getElementById("mp-LostAddress");
formpType = document.getElementById("mp-Type");
formpCompany = document.getElementById("mp-Company");
formpModel = document.getElementById("mp-Model");
formpOS = document.getElementById("mp-OS");
formpOSversion = document.getElementById("mp-osVersion");
formpAnyPassword = document.getElementById("mp-AnyPassword");
formpImg = document.getElementById("mp-Img");
formpDescription = document.getElementById("mp-Description");

function mpShowDetails(_registerer, _LostAddress, _PhoneType, _PhoneCompany, _PhoneModel, _PhoneOS, _osVersion, _AnyPassword, _PhoneImg, _Description) {
    formpImg.src = _PhoneImg;
    formpLostAddress.innerHTML = _LostAddress;
    formpType.innerHTML = _PhoneType;
    formpCompany.innerHTML = _PhoneCompany;
    formpModel.innerHTML = _PhoneModel;
    formpOS.innerHTML = _PhoneOS;
    formpOSversion.innerHTML = _osVersion;
    formpAnyPassword.innerHTML = _AnyPassword;
    formpDescription.innerHTML = _Description;

    mpdetailsContent.style.display = "block";
    //  console.log(name);
    //  alert("clicked! "+name);  
}

mpcloseIcon.onclick = () => { mpdetailsContent.style.display = "none"; }



// -------Delete Laptop Document----------------
function Delete(id) {
    cloudDB.collection("Found_Laptop_Registered").doc(id).delete().then(
        function () {
            alert("Delete Successfully!");
            console.log("Document deleted successfully");
            location.reload();

        }).catch(function (error) {
            alert("Error: " + error.code + ", " + error.message);
            console.log("Error deleting document");
        });
}

// -------Delete Phone Document----------------
function mpDelete(id) {
    cloudDB.collection("Found_MobilePhone_Registered").doc(id).delete().then(
        function () {
            alert("Delete Successfully!");
            console.log("Document deleted successfully");
            location.reload();

        }).catch(function (error) {
            alert("Error: " + error.code + ", " + error.message);
            console.log("Error deleting document");
        });
}


let nav_btn = document.getElementById("nav-btn");
let nav_container = document.getElementById("nav-container");
let nav_menu = document.getElementById("nav-menu");

let rest_area = document.getElementById("rest-area");


rest_area.onclick = () => {
    rest_area.classList.toggle("rest-area-disable");
    nav_container.classList.toggle("min-nav");
    nav_menu.classList.toggle("nav-menu-disable");
}

function toggleNav() {
    rest_area.classList.toggle("rest-area-disable");
    nav_container.classList.toggle("min-nav");
    nav_menu.classList.toggle("nav-menu-disable");
}