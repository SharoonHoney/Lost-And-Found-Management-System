let emailAddressV;
function Update(val, type) {
    if (type == 'emailAddress') {
        emailAddressV = val;
    }
}

resetPass = firebase.auth();

function resetPassword() {
    resetPass.sendPasswordResetEmail(emailAddressV).then(function() {
        alert("Successfully! send reset link to your email");
        location.replace("newLoginRegister.html");
    }).catch(function(error){
        alert(error.message);
    }); 

}
