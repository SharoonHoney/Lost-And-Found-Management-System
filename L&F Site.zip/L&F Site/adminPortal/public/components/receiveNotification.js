// Initialize Firebase
// firebase.initializeApp(firebaseConfig);
// firebase.analytics();

let FIRESTORE_DATABASE = firebase.firestore();
let STORAGE = firebase.storage();
let AUTH = firebase.auth();

let notification = document.getElementById("notification-container");
let marker = document.getElementById("marker");


let forApproveNotify = "";
forApproveNotify = document.getElementById("approveNotify");

// Notification data Container

let notification_list = document.getElementById("notification-list");


let SR = 0;

// ======================
// FIRESTORE_DATABASE.collection("Found_Laptop_Registered").
//     onSnapshot(snapshot => {

//         let changes = snapshot.docChanges();


//         changes.forEach(change => {

//             if (change.type == 'added') {

//                 FIRESTORE_DATABASE.collection("Lost_Laptop_Registered").get().then((querySnapshot) => {
//                     querySnapshot.forEach((doc2) => {
//                         // doc.data() is never undefined for query doc snapshots
//                         // if (change.doc.data().LaptopCompany == doc2.data().LaptopCompany && change.doc.data().LaptopModel == doc2.data().LaptopModel && change.doc.data().User != doc2.data().User) {
//                         if (change.doc.data().LaptopCompany == doc2.data().LaptopCompany && change.doc.data().LaptopModel == doc2.data().LaptopModel) {

//                             // notification_list.innerHTML += "<li>"+(++SR)+" | Laptop Match Found <button type='button' onclick='showDetails(\""+doc.data()+"\", \""+doc2.data()+"\")'>View Details</button></li>";
//                             // notification_list.innerHTML += "<li>"+(++SR)+" | Laptop Match Found <button type='button' onclick=showDetails(\""+doc1.id+"\", \""+doc2.id+"\", \""+doc1.data().User+"\", \""+doc2.data().User+"\", \""+doc1.data().LostAddress+"\", \""+doc2.data().LostAddress+"\", \""+doc1.data().LaptopCompany+"\", \""+doc2.data().LaptopCompany+"\", \""+doc1.data().LaptopModel+"\", \""+doc2.data().LaptopModel+"\", \""+doc1.data().LaptopOS+"\", \""+doc2.data().LaptopOS+"\", \""+doc1.data().osVersion+"\", \""+doc2.data().osVersion+"\", \""+doc1.data().AnyPassword+"\", \""+doc2.data().AnyPassword+"\", \""+doc1.data().LaptopImg+"\", \""+doc2.data().LaptopImg+"\", \""+doc1.data().Description+"\", \""+doc2.data().Description+"\")>View Details</button></li>";
//                             notification_list.innerHTML += "<li>" + (++SR) + " | Laptop Match Found <button type='button' onclick='showDetails(\"" + doc1.data().User + "\", \"" + doc2.data().User + "\", \"" + doc1.data().LostAddress + "\", \"" + doc2.data().FoundAddress + "\", \"" + doc1.data().LaptopCompany + "\", \"" + doc2.data().LaptopCompany + "\", \"" + doc1.data().LaptopModel + "\", \"" + doc2.data().LaptopModel + "\", \"" + doc1.data().LaptopOS + "\", \"" + doc2.data().LaptopOS + "\", \"" + doc1.data().osVersion + "\", \"" + doc2.data().osVersion + "\", \"" + doc1.data().AnyPassword + "\", \"" + doc2.data().PasswordProtected + "\", \"" + doc1.data().LaptopImg + "\", \"" + doc2.data().LaptopImg + "\", \"" + doc1.data().Description + "\", \"" + doc2.data().Description + "\")'>View Details</button></li>";
//                             // console.log(doc.id, " => ", doc.data());
//                             // FilterDB(doc.id, doc.data().User, doc.data().LostAddress, doc.data().LaptopCompany, doc.data().LaptopModel, doc.data().LaptopOS, doc.data().osVersion, doc.data().AnyPassword, doc.data().LaptopImg, doc.data().Description);
//                             forApproveNotify.onclick = function () {
//                                 FIRESTORE_DATABASE.collection("Users").get().then((querySnapshot) => {
//                                     querySnapshot.forEach((doc3) => {

//                                         if (doc2.data().User == doc3.data().Email) {
//                                             alert("User: " + doc3.data().Email + " id: " + doc3.id);

//                                             sendNotification(doc3.id, doc2.data().User);
//                                         }

//                                     });
//                                 });

//                                 // FIRESTORE_DATABASE.collection("Claim_Notification").
//                             }

//                         }
//                         else {
//                             console.log("No match Found");
//                         }

//                     });
//                 });
//             }


//         });


//     });
// ======================



FIRESTORE_DATABASE.collection("Lost_Laptop_Registered").get().then((querySnapshot) => {
    querySnapshot.forEach((doc1) => {
        // doc.data() is never undefined for query doc snapshots
        FIRESTORE_DATABASE.collection("Found_Laptop_Registered").get().then((querySnapshot) => {
            
            querySnapshot.forEach((doc2) => {
                if (doc1.data().User != doc2.data().User && doc1.data().LaptopCompany == doc2.data().LaptopCompany ) {
                    // notification_list.innerHTML += "<li>"+(++SR)+" | Laptop Match Found <button type='button' onclick='showDetails(\""+doc.data()+"\", \""+doc2.data()+"\")'>View Details</button></li>";
                    // notification_list.innerHTML += "<li>"+(++SR)+" | Laptop Match Found <button type='button' onclick=showDetails(\""+doc1.id+"\", \""+doc2.id+"\", \""+doc1.data().User+"\", \""+doc2.data().User+"\", \""+doc1.data().LostAddress+"\", \""+doc2.data().LostAddress+"\", \""+doc1.data().LaptopCompany+"\", \""+doc2.data().LaptopCompany+"\", \""+doc1.data().LaptopModel+"\", \""+doc2.data().LaptopModel+"\", \""+doc1.data().LaptopOS+"\", \""+doc2.data().LaptopOS+"\", \""+doc1.data().osVersion+"\", \""+doc2.data().osVersion+"\", \""+doc1.data().AnyPassword+"\", \""+doc2.data().AnyPassword+"\", \""+doc1.data().LaptopImg+"\", \""+doc2.data().LaptopImg+"\", \""+doc1.data().Description+"\", \""+doc2.data().Description+"\")>View Details</button></li>";
                    notification_list.innerHTML += "<li>" + (++SR) + " | Laptop Match Found <button type='button' onclick='showDetails(\"" + doc1.data().User + "\", \"" + doc2.data().User + "\", \"" + doc1.data().LostAddress + "\", \"" + doc2.data().FoundAddress + "\", \"" + doc1.data().LaptopCompany + "\", \"" + doc2.data().LaptopCompany + "\", \"" + doc1.data().LaptopModel + "\", \"" + doc2.data().LaptopModel + "\", \"" + doc1.data().LaptopOS + "\", \"" + doc2.data().LaptopOS + "\", \"" + doc1.data().osVersion + "\", \"" + doc2.data().osVersion + "\", \"" + doc1.data().AnyPassword + "\", \"" + doc2.data().PasswordProtected + "\", \"" + doc1.data().LaptopImg + "\", \"" + doc2.data().LaptopImg + "\", \"" + doc1.data().Description + "\", \"" + doc2.data().Description + "\")'>View Details</button></li>";
                    // console.log(doc.id, " => ", doc.data());
                    // FilterDB(doc.id, doc.data().User, doc.data().LostAddress, doc.data().LaptopCompany, doc.data().LaptopModel, doc.data().LaptopOS, doc.data().osVersion, doc.data().AnyPassword, doc.data().LaptopImg, doc.data().Description);
                    forApproveNotify.onclick = function () {
                        FIRESTORE_DATABASE.collection("Users").get().then((querySnapshot) => {
                            querySnapshot.forEach((doc3) => {

                                if (doc1.data().User == doc3.data().Email) {
                                    alert("User: " + doc3.data().Email + " id: " + doc3.id);

                                    sendNotification(doc3.id, doc1.data().User, doc2.data().User);
                                }

                            });
                        });

                        // FIRESTORE_DATABASE.collection("Claim_Notification").
                    }

                }
                else {
                    console.log("No match Found");
                }

            });
        });
    });
});

// ------------Send Notification-------------------
function sendNotification(ID, user, claimToUser) {
    FIRESTORE_DATABASE.collection("Claim_Notification").doc(ID).get().then(
        function (doc) {
            $.ajax({
                url: 'https://fcm.googleapis.com/fcm/send',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'key=AAAADIs-RLE:APA91bFK-0Dqv5eHU3z03ep7r4Js_tEVoDfIFWOjP8eeVhR5esjyOAEsPIWr5zQls3-6RBWXqksURPf6VdregPhyQRLouVBtP1LsCkw2cN6KJw1l65ZCO1nVj6WEwqXbZgfGg3IJeims'
                },
                data: JSON.stringify({
                    'to': doc.data().token,
                    'data': {
                        'message': 'Some Info Found',
                        'openURL': 'https://lostandfound.ga',

                        // "webpush": {
                        //     "fcm_options": {
                        //         "link": "https://lostandfound.ga"
                        //     }
                        // }
                    }
                    // 'url' : 'lostandfound.ga'

                }),
                success: (response) => {
                    // alert(response);
                    console.log(response);
                    FIRESTORE_DATABASE.collection("Notifications").add({
                        uid: ID,
                        user: user,
                        claim_To_User: claimToUser,
                        data: "Some Info Found About your device.",
                        mark: "un-read"
                    }).then(() => {
                        alert("Notification Sends Successfully!");
                    }).catch((error) => {
                        alert("Error: " + error.message);
                    });
                },
                error: (xhr, status, error) => {
                    // alert(xhr.error);
                    console.log(xhr.error);
                }
            });
        }
    ).catch(function (error) {
        console.log('error ', error);
    });

}












//------------Show Laptop Details-------------- 
let detailsContent = document.getElementById("details-content");
let closeIcon = "";

let forLostUser = "";
let forLostAddress = "";
let forLostLaptopCompany = "";
let forLostLaptopModel = "";
let forLostLaptopOS = "";
let forLostOSversion = "";
let forLostAnyPassword = "";
let forLostLaptopImg = "";
let forLostDescription = "";

let forFoundUser = "";
let forFoundAddress = "";
let forFoundLaptopCompany = "";
let forFoundLaptopModel = "";
let forFoundLaptopOS = "";
let forFoundOSversion = "";
let forFoundAnyPassword = "";
let forFoundLaptopImg = "";
let forFoundDescription = "";

closeIcon = document.getElementById("closeIcon");

forLostUser = document.getElementById("Lost_userName");
forLostAddress = document.getElementById("LostAddress");
forLostLaptopCompany = document.getElementById("LostLaptopCompany");
forLostLaptopModel = document.getElementById("LostLaptopModel");
forLostLaptopOS = document.getElementById("LostLaptopOS");
forLostOSversion = document.getElementById("Lost_osVersion");
forLostAnyPassword = document.getElementById("LostAnyPassword");
forLostLaptopImg = document.getElementById("LostLaptopImg");
forLostDescription = document.getElementById("LostDescription");

forFoundUser = document.getElementById("Found_userName");
forFoundAddress = document.getElementById("FoundAddress");
forFoundLaptopCompany = document.getElementById("FoundLaptopCompany");
forFoundLaptopModel = document.getElementById("FoundLaptopModel");
forFoundLaptopOS = document.getElementById("FoundLaptopOS");
forFoundOSversion = document.getElementById("Found_osVersion");
forFoundAnyPassword = document.getElementById("FoundAnyPassword");
forFoundLaptopImg = document.getElementById("FoundLaptopImg");
forFoundDescription = document.getElementById("FoundDescription");

// function showDetails(lost, found, lost_registerer, found_registerer, _LostAddress, _FoundAddress, Lost_LaptopCompany, Found_LaptopCompany, Lost_LaptopModel, Found_LaptopModel, Lost_LaptopOS, Found_LaptopOS, Lost_osVersion, Found_osVersion, Lost_AnyPassword, Found_AnyPassword, Lost_LaptopImg, Found_LaptopImg, Lost_Description, Found_Description) {
function showDetails(_LostUser, _FoundUser, _LostAddress, _FoundAddress, Lost_LaptopCompany, Found_LaptopCompany, Lost_LaptopModel, Found_LaptopModel, Lost_LaptopOS, Found_LaptopOS, Lost_osVersion, Found_osVersion, Lost_AnyPassword, Found_AnyPassword, Lost_LaptopImg, Found_LaptopImg, Lost_Description, Found_Description) {
    // function showDetails(lost, found) {
    forLostUser.innerHTML = _LostUser;
    forFoundUser.innerHTML = _FoundUser;
    forLostLaptopImg.src = Lost_LaptopImg;
    forFoundLaptopImg.src = Found_LaptopImg;
    forLostAddress.innerHTML = _LostAddress;
    forFoundAddress.innerHTML = _FoundAddress;
    forLostLaptopCompany.innerHTML = Lost_LaptopCompany;
    forFoundLaptopCompany.innerHTML = Found_LaptopCompany;
    forLostLaptopModel.innerHTML = Lost_LaptopModel;
    forFoundLaptopModel.innerHTML = Found_LaptopModel;
    forLostLaptopOS.innerHTML = Lost_LaptopOS;
    forFoundLaptopOS.innerHTML = Found_LaptopOS;
    forLostOSversion.innerHTML = Lost_osVersion;
    forFoundOSversion.innerHTML = Found_osVersion;
    forLostAnyPassword.innerHTML = Lost_AnyPassword;
    forFoundAnyPassword.innerHTML = Found_AnyPassword;
    forLostDescription.innerHTML = Lost_Description;
    forFoundDescription.innerHTML = Found_Description;

    detailsContent.style.display = "block";
    //  console.log(name);
    //  alert("clicked! "+name);  
}

closeIcon.onclick = () => { detailsContent.style.display = "none"; }


