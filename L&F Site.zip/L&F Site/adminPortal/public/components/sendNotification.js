function approved(userEmail) {

    cloudDB.collection("Claim_Notification").add({
        Notification: userEmail,
        Mark: "unread"
    }).then(
        function () {
            // Push.create("New Notification", {
            //     body: userEmail,
            //     // icon: '/icon.png',
            //     timeout: 4000,
            //     onClick: function () {
            //         window.focus();
            //         this.close();
            //     }
            // });
           
            console.log("Notification Successfully!");
        }).catch (
            function (error) {
             alert ("Error: "+error.code+", "+error.message);
            }
        );
}
