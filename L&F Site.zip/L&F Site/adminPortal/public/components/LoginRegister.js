// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();

let cloudDB = firebase.firestore();
let firebaseLogin = firebase.auth();
let userID;


let nameV;
let cnicV;
let mobileNoV;
let emailAddressV;
let passwordV;
let confirmPasswordV;

let switchScreen = 1;

// Inputs by IDs
let myName = document.getElementById("name");
let myCnic = document.getElementById("cnic");
let myMobileNo = document.getElementById("mobileNo");
let myEmailAddress = document.getElementById("emailAddress");
let myPassword = document.getElementById("password");
let myConfirmPassword = document.getElementById("confirmPassword");
// let forgotPassword = document.getElementById("forgotPassword");

//-------------------------------------------------------------------    




function Update(val, type) {

    if (type == 'name') {
        nameV = val;
    }
    else if (type == 'cnic') {
        cnicV = val;
    }
    else if (type == 'mobileNo') {
        mobileNoV = val;
    }
    else if (type == 'emailAddress') {
        emailAddressV = val;
    }
    else if (type == 'password') {
        passwordV = val;
    }
    else if (type == 'confirmPassword') {
        confirmPasswordV = val;
        console.log("confirmPassword")
        if (confirmPasswordV === passwordV) {
            confirmpassword_field.style.border = "5px solid";
            confirmpassword_field.style.borderColor = "#00B526";
        }
        else {
            confirmpassword_field.style.borderColor = "red";

        }
    }
}







let formContainer = document.getElementById("formContainer");
let namefield = document.getElementById("namefield");
let cnicfield = document.getElementById("cnicfield");
let mobilefield = document.getElementById("mobilefield");
let emailfield = document.getElementById("emailfield");
let password_field = document.getElementById("password-field");
let confirmpassword_field = document.getElementById("confirmpassword-field");

let togglePassword1 = document.getElementById("togglePassword1");
let togglePassword2 = document.getElementById("togglePassword2");
let submitbtn = document.getElementById("submit-btn");

let passwordToggle = document.getElementById("password");
let confirmPasswordToggle = document.getElementById("confirmPassword");

let logo = document.getElementById("logo");
// formContainer.style.transition = "all 2s";
// confirmpassword_field.style.display = "none";

let forgotPassword = document.getElementById("forgotPassword");
openLoginPage();

togglePassword1.onclick = function () {
    togglePassword1.classList.toggle("bi-eye");
    if (passwordToggle.type === "password") {
        passwordToggle.type = "text";

    } else {
        passwordToggle.type = "password";

    }

}
togglePassword2.onclick = function () {
    togglePassword2.classList.toggle("bi-eye");
    if (confirmPasswordToggle.type === "password") {
        confirmPasswordToggle.type = "text";

    } else {
        confirmPasswordToggle.type = "password";

    }
}


function openLoginPage() {
    logo.style.maxHeight = "100%";
    logo.style.opacity = "1";

    namefield.style.maxHeight = "0";
    cnicfield.style.maxHeight = "0";
    mobilefield.style.maxHeight = "0";


    namefield.style.opacity = "0";
    cnicfield.style.opacity = "0";
    mobilefield.style.opacity = "0";

    namefield.style.transition = "max-height 0s, opacity 0.5s linear";
    cnicfield.style.transition = "max-height 0s, opacity 0.5s linear";
    mobilefield.style.transition = "max-height 0s, opacity 0.5s linear";

    confirmpassword_field.style.visibility = "hidden";
    confirmpassword_field.style.opacity = "0";
    confirmpassword_field.style.transition = "visibility 0s, opacity 0.5s linear";
    forgotPassword.style.display = "block";
    submitbtn.innerText = "Sign In";

    document.getElementById("switch-btn").innerText = "Create An Account";


}

function openSignUpPage() {
    logo.style.maxHeight = "0";
    logo.style.opacity = "0";

    logo.style.transition = "max-height 0s, opacity 0.5s linear";

    namefield.style.maxHeight = "100%";
    cnicfield.style.maxHeight = "100%";
    mobilefield.style.maxHeight = "100%";

    namefield.style.opacity = "1";
    cnicfield.style.opacity = "1";
    mobilefield.style.opacity = "1";

    confirmpassword_field.style.visibility = "visible";
    confirmpassword_field.style.opacity = "1";

    forgotPassword.style.display = "none";
    submitbtn.innerText = "Sign Up";

    document.getElementById("switch-btn").innerText = "Already have an Account? Log In";



}


let register = false;
function registerUser() {
    firebaseLogin.createUserWithEmailAndPassword(emailAddressV, passwordV)
        .then(function () {

            userID = firebaseLogin.currentUser.uid;
            cloudDB.collection("Admin").doc(userID).set({
                Name: nameV,
                CNIC: cnicV,
                MobileNo: mobileNoV,
                Email: emailAddressV
            }).then(function () {
                console.log("Document written with ID: " + userID);
            }).catch(function (error) {

                console.log("Document written error: ");
            });

            alert("Sign Up! Successfully")
            console.log("User successfully registered with id: " + userID);
            updateFields();

        }).catch(function (error) {
            alert("" + error.message);
        });


}



// ---Login User-----
function loginUser() {
    firebaseLogin.signInWithEmailAndPassword(emailAddressV, passwordV)
        .then(function () {
            userID = firebaseLogin.currentUser.uid;
            alert("Login Successfully!");
            updateFields();
            location.reload();

        }).catch(function (error) {
            alert("" + error.message);
        });
}

//  // ---Check User---
 firebaseLogin.onAuthStateChanged((user) => {
    if (user && switchScreen == 1) {
        location.replace("index.html");
    }
// else if(switchScreen == 2) {
//     location.replace("newLoginRegister.html");

//    }   
   });


function updateFields() {
    myName.value = "";
    myCnic.value = "";
    myMobileNo.value = "";
    myEmailAddress.value = "";
    myPassword.value = "";
    myConfirmPassword.value = "";

    nameV = "";
    cnicV = "";
    mobileNoV = "";
    emailAddressV = "";
    passwordV = "";
    confirmPasswordV = "";
}



// Switch Login and Register Screens

document.getElementById("switch-btn").onclick = function () {


    /*
    nameV = val;
    cnicV = val;
    mobileNoV = val;
    emailAddressV = val;
    passwordV = val;
    confirmPasswordV = val;
    */
    if (document.getElementById("switch-btn").innerText === "Create An Account") {
        openSignUpPage();
        switchScreen = 2;
    }
    else {
        openLoginPage();
        switchScreen = 1;
    }
    console.log(switchScreen);
}

//  Sign In and Sign Up Button

document.getElementById("submit-btn").onclick = function () {
    if (switchScreen == 1) {
        console.log("Sign In");

        loginUser();

        // ---Check User---
        // firebaseLogin.onAuthStateChanged((user) => {
        //     if (user) {
        //         location.replace("index.html");
        //     }


        // });
    }

    
    else if (switchScreen == 2) {
        console.log("Sign Up");

        registerUser();

    }
}
document.getElementById("formSubmit").addEventListener("keyup", (event)=>{
    if (event.keyCode == 13) {
        event.preventDefault();

        if (switchScreen == 1) {
            console.log("Sign In");
    
            loginUser();
    
            // ---Check User---
            // firebaseLogin.onAuthStateChanged((user) => {
            //     if (user) {
            //         location.replace("index.html");
            //     }
    
    
            // });
        }
    
        
        else if (switchScreen == 2) {
            console.log("Sign Up");
    
            registerUser();
    
        }
    }
});

forgotPassword.onclick = () => {
    forgotPassword.href = "resetPassword.html";
}

