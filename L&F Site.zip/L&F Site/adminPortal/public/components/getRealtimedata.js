
let lostLaptopRegisterd = 0;
let foundLaptopRegisterd = 0;
let lostMobileRegisterd = 0;
let foundMobileRegisterd = 0;

let totalLaptopRegistered = 0;
let totalMobileRegistered = 0;


FIRESTORE_DATABASE.collection("Lost_Laptop_Registered").get().then(
    function (snapshot) {
         snapshot.docs.forEach((doc) => {
            ++lostLaptopRegisterd;
        });
                
  }).catch(function (error) {
        alert("Error: " + error.code + ", " + error.message);
        console.log('error ', error);
 });

FIRESTORE_DATABASE.collection("Found_Laptop_Registered").get().then(
    function (snapshot) {
         snapshot.docs.forEach((doc) => {
            ++foundLaptopRegisterd;
        });
                
  }).catch(function (error) {
        alert("Error: " + error.code + ", " + error.message);
        console.log('error ', error);
 });

FIRESTORE_DATABASE.collection("Lost_MobilePhone_Registered").get().then(
    function (snapshot) {
         snapshot.docs.forEach((doc) => {
            ++lostMobileRegisterd;
        });
                
  }).catch(function (error) {
        alert("Error: " + error.code + ", " + error.message);
        console.log('error ', error);
 });

FIRESTORE_DATABASE.collection("Found_MobilePhone_Registered").get().then(
    function (snapshot) {
         snapshot.docs.forEach((doc) => {
            ++foundMobileRegisterd;
        });
                
  }).catch(function (error) {
        alert("Error: " + error.code + ", " + error.message);
        console.log('error ', error);
 });




// FIRESTORE_DATABASE.collection("Lost_MobilePhone_Registered").
// onSnapshot(snapshot => {
//     let changes = snapshot.docChanges();
// //  document.getElementById("noData").style.visibility = "visible";
//     changes.forEach(change => {
       
//         if (change.type == 'added') {
//            ++lostMobileRegisterd;
//         }


//     });


// });

// FIRESTORE_DATABASE.collection("Found_MobilePhone_Registered").
// onSnapshot(snapshot => {
//     let changes = snapshot.docChanges();
// //  document.getElementById("noData").style.visibility = "visible";
//     changes.forEach(change => {
       
//         if (change.type == 'added') {
//            ++foundMobileRegisterd;
//         }


//     });


// });

// FIRESTORE_DATABASE.collection("Lost_MobilePhone_Registered").
// onSnapshot(snapshot => {
//     let changes = snapshot.docChanges();
// //  document.getElementById("noData").style.visibility = "visible";
//     changes.forEach(change => {
       
//         if (change.type == 'added') {
//            ++lostMobileRegisterd;
//         }


//     });


// });

// FIRESTORE_DATABASE.collection("Found_MobilePhone_Registered").
// onSnapshot(snapshot => {
//     let changes = snapshot.docChanges();
// //  document.getElementById("noData").style.visibility = "visible";
//     changes.forEach(change => {
       
//         if (change.type == 'added') {
//            ++foundMobileRegisterd;
//         }


//     });


// });

totalLaptopRegistered = lostLaptopRegisterd + foundLaptopRegisterd;

totalMobileRegistered = lostMobileRegisterd + foundMobileRegisterd;

let totalItemRegistered = totalLaptopRegistered + totalMobileRegistered;

// document.getElementById("total-item").innerHTML = "66"+totalItemRegistered;