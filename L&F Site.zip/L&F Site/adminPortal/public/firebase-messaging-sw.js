importScripts('https://www.gstatic.com/firebasejs/8.7.1/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.7.1/firebase-messaging.js');

const firebaseConfig = {
  apiKey: "AIzaSyD53m9EJCSDXXwxMG3C9kOB-qF2-W3561w",
  authDomain: "lostandfoundmanagementsystem.firebaseapp.com",
  projectId: "lostandfoundmanagementsystem",
  storageBucket: "lostandfoundmanagementsystem.appspot.com",
  messagingSenderId: "53875721393",
  appId: "1:53875721393:web:6f945a8701d2c110a00e90",
  measurementId: "G-CPR08W8Z5N"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log('[firebase-messaging-sw.js] Received background message ', payload);
  // Customize notification here
  const notificationTitle = 'You recieved a new message';
  const notificationOptions = {
    // body: 'You have.',
    body: payload.data.message,
    click_action: payload.data.url,
    icon: '/firebase-logo.png'
  };

  return self.registration.showNotification(notificationTitle,
    notificationOptions);
});
