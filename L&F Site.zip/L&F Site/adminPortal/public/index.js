let nav_btn = document.getElementById("nav-btn");
let nav_container = document.getElementById("nav-container");
let nav_menu = document.getElementById("nav-menu");
let notification_icon = document.getElementById("notification-icon");
let notification_container = document.getElementById("notification-container");

let rest_area = document.getElementById("rest-area");
notification_icon.onclick = () => {
    notification_container.style.display = "block";
    rest_area.style.display = "block"
}


rest_area.onclick = () => {
    rest_area.classList.toggle("rest-area-disable");
    nav_container.classList.toggle("min-nav");
    nav_menu.classList.toggle("nav-menu-disable");
    notification_container.style.display = "none";
}

function toggleNav() {
    rest_area.classList.toggle("rest-area-disable");
    nav_container.classList.toggle("min-nav");
    nav_menu.classList.toggle("nav-menu-disable");
}

